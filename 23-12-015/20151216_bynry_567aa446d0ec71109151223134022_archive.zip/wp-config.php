<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'tungst10_testbynry_wp');

/** MySQL database username */
define('DB_USER', 'tungst10_wp');

/** MySQL database password */
define('DB_PASSWORD', 'bynry@2015');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Iyl,P-j;GRix+[&pYiTIiGi.z)c.L,;3_UFd+tU g}z`49D`(-hC(8hzX--nhr[h');
define('SECURE_AUTH_KEY',  'mhBkV(_w[JnK5JkvZfllf*@cT+:),nK}#.s@DKnv0^}V+S)$h!%19c^%b$j<?Xq7');
define('LOGGED_IN_KEY',    'h*RI+CgR/`0x]^M|JSb3B!4Ql^=+>_-woXBcaG|Pm1dm:TF)6!A|&|l61AGNAh2z');
define('NONCE_KEY',        'Z#;|b%4/}$B* #x)Awv8z=S$-O}LJ%+kSS3i8Pcs0XwTlRD$02&[{(l`YB*y,N4q');
define('AUTH_SALT',        'SI]/R:}2vPy$^-dR)??t%~nm44-~|T/ze[ns6Z>fz8 Gp:i0(O|Oc%RM3)^MH)?V');
define('SECURE_AUTH_SALT', '[V&GL{oXd_^-z6.nI:1X$/)--3wND88kv+B&f3z5_BI0:32s{eqU-J;pr-ao{Q,!');
define('LOGGED_IN_SALT',   'eRFz22i32G0+npKXA+uin0|igRc!zWQ_XA+49XfUn;;9ik2yv<qbN]oR)ygLWvkc');
define('NONCE_SALT',       '>oui7cPywIygB,?+vchiZBw#)E^e{u|MC.F|Xr;h~n@H1w2e<RUMr]i6,;tJ$bw=');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
